import sys
sys.path.insert(0,'..')

from VideoDb import VideoDB

# videoDb = VideoDB('VideoDB.db')
# # get all videos
# videos = videoDb.show_videos()
# print(videos)
# # upload a video to db
# videoDb.add_video({"user": "aldison", "videoLink":"https://..", "videoCover": "https://google.com", "description": "hello world", "videoPath": "/videos/..."})
# # delete a video
# videoDb.delete_video(1)